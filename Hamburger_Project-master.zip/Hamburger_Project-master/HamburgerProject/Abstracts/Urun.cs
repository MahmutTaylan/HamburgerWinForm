﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HamburgerProject.Abstracts
{
    public abstract class Urun
    {
        public string Ad { get; set; }

        public decimal Fiyat { get; set; }


    }
}
