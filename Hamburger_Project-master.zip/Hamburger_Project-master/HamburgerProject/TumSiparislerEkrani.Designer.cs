﻿namespace HamburgerProject
{
    partial class TumSiparislerEkrani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox4 = new GroupBox();
            lblSatilanUrunAdedi = new Label();
            groupBox3 = new GroupBox();
            lblEkMalzemeGeliri = new Label();
            groupBox2 = new GroupBox();
            lblToplamSiparis = new Label();
            groupBox1 = new GroupBox();
            lblCiro = new Label();
            lboxSiparisler = new ListBox();
            label1 = new Label();
            groupBox4.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(lblSatilanUrunAdedi);
            groupBox4.Location = new Point(707, 435);
            groupBox4.Margin = new Padding(2);
            groupBox4.Name = "groupBox4";
            groupBox4.Padding = new Padding(2);
            groupBox4.Size = new Size(229, 104);
            groupBox4.TabIndex = 20;
            groupBox4.TabStop = false;
            groupBox4.Text = "Satılan Ürün Adedi";
            // 
            // lblSatilanUrunAdedi
            // 
            lblSatilanUrunAdedi.AutoSize = true;
            lblSatilanUrunAdedi.Font = new Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point);
            lblSatilanUrunAdedi.ForeColor = Color.Red;
            lblSatilanUrunAdedi.Location = new Point(39, 39);
            lblSatilanUrunAdedi.Margin = new Padding(2, 0, 2, 0);
            lblSatilanUrunAdedi.Name = "lblSatilanUrunAdedi";
            lblSatilanUrunAdedi.Size = new Size(38, 45);
            lblSatilanUrunAdedi.TabIndex = 3;
            lblSatilanUrunAdedi.Text = "0";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(lblEkMalzemeGeliri);
            groupBox3.Location = new Point(707, 303);
            groupBox3.Margin = new Padding(2);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(2);
            groupBox3.Size = new Size(229, 104);
            groupBox3.TabIndex = 21;
            groupBox3.TabStop = false;
            groupBox3.Text = "Ekstra Malzeme Geliri";
            // 
            // lblEkMalzemeGeliri
            // 
            lblEkMalzemeGeliri.AutoSize = true;
            lblEkMalzemeGeliri.Font = new Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point);
            lblEkMalzemeGeliri.ForeColor = Color.Red;
            lblEkMalzemeGeliri.Location = new Point(39, 39);
            lblEkMalzemeGeliri.Margin = new Padding(2, 0, 2, 0);
            lblEkMalzemeGeliri.Name = "lblEkMalzemeGeliri";
            lblEkMalzemeGeliri.Size = new Size(83, 45);
            lblEkMalzemeGeliri.TabIndex = 3;
            lblEkMalzemeGeliri.Text = "0.00";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lblToplamSiparis);
            groupBox2.Location = new Point(707, 182);
            groupBox2.Margin = new Padding(2);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(2);
            groupBox2.Size = new Size(229, 104);
            groupBox2.TabIndex = 22;
            groupBox2.TabStop = false;
            groupBox2.Text = "Toplam Sipariş";
            // 
            // lblToplamSiparis
            // 
            lblToplamSiparis.AutoSize = true;
            lblToplamSiparis.Font = new Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point);
            lblToplamSiparis.ForeColor = Color.Red;
            lblToplamSiparis.Location = new Point(39, 39);
            lblToplamSiparis.Margin = new Padding(2, 0, 2, 0);
            lblToplamSiparis.Name = "lblToplamSiparis";
            lblToplamSiparis.Size = new Size(38, 45);
            lblToplamSiparis.TabIndex = 3;
            lblToplamSiparis.Text = "0";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblCiro);
            groupBox1.Location = new Point(707, 61);
            groupBox1.Margin = new Padding(2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(2);
            groupBox1.Size = new Size(229, 104);
            groupBox1.TabIndex = 19;
            groupBox1.TabStop = false;
            groupBox1.Text = "Ciro";
            // 
            // lblCiro
            // 
            lblCiro.AutoSize = true;
            lblCiro.Font = new Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point);
            lblCiro.ForeColor = Color.Red;
            lblCiro.Location = new Point(39, 39);
            lblCiro.Margin = new Padding(2, 0, 2, 0);
            lblCiro.Name = "lblCiro";
            lblCiro.Size = new Size(83, 45);
            lblCiro.TabIndex = 3;
            lblCiro.Text = "0.00";
            // 
            // lboxSiparisler
            // 
            lboxSiparisler.FormattingEnabled = true;
            lboxSiparisler.ItemHeight = 25;
            lboxSiparisler.Location = new Point(25, 61);
            lboxSiparisler.Margin = new Padding(2);
            lboxSiparisler.Name = "lboxSiparisler";
            lboxSiparisler.Size = new Size(648, 479);
            lboxSiparisler.TabIndex = 18;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(25, 20);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(319, 45);
            label1.TabIndex = 17;
            label1.Text = "Alınan Tüm Siparişler";
            // 
            // TumSiparislerEkrani
            // 
            AutoScaleDimensions = new SizeF(11F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(982, 566);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(lboxSiparisler);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 2, 3, 2);
            Name = "TumSiparislerEkrani";
            Text = "TumSiparislerEkrani";
            Load += TumSiparislerEkrani_Load;
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox4;
        private Label lblSatilanUrunAdedi;
        private GroupBox groupBox3;
        private Label lblEkMalzemeGeliri;
        private GroupBox groupBox2;
        private Label lblToplamSiparis;
        private GroupBox groupBox1;
        private Label lblCiro;
        private ListBox lboxSiparisler;
        private Label label1;
    }
}